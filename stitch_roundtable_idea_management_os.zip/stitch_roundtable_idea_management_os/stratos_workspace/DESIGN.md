# Design System: The Editorial Engine

## 1. Overview & Creative North Star
The "Editorial Engine" is the visual foundation for this design system. It moves away from the "SaaS-in-a-box" look by treating digital productivity as a high-end editorial experience. Instead of rigid grids and heavy borders, we utilize **Architectural Clarity**—a philosophy where space is a functional element, and hierarchy is defined by light and depth rather than lines. 

The goal is to provide a "quiet" interface that recedes to let the user's work and the AI personas' insights take center stage. We leverage intentional asymmetry, generous breathing room, and a sophisticated tonal palette to create a workspace that feels like a premium physical studio.

---

## 2. Colors & Tonal Architecture
The palette is rooted in a sophisticated Indigo (`primary: #5148d8`) and a deep Teal (`secondary: #006b62`). This system relies on "Tonal Depth" to organize information.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to section off the UI. Boundaries must be defined solely through background color shifts. Use `surface-container-low` for large background sections and `surface-container-lowest` (pure white) for active content areas. 

### Surface Hierarchy & Nesting
Treat the UI as a series of nested layers, similar to sheets of fine paper:
- **Base Layer:** `surface` (#f7f9fb)
- **Sub-Sectioning:** `surface-container-low` (#f1f4f6)
- **Primary Content Cards:** `surface-container-lowest` (#ffffff)
- **Interactive/Hover States:** `surface-container-high` (#e3e9ec)

### The Glass & Gradient Rule
For floating elements (modals, AI overlays), use **Glassmorphism**. Apply a semi-transparent `surface` color with a `20px` to `40px` backdrop-blur. 
- **Signature Texture:** Use a subtle linear gradient on primary CTAs transitioning from `primary` (#5148d8) to `primary_dim` (#453acc) at a 135-degree angle. This adds "soul" and prevents the UI from feeling flat.

### Idea Stage Color Mapping
Stages are differentiated via soft, desaturated accents to maintain the minimalist aesthetic:
- **Inbox/Spark:** `primary_container`
- **Exploring/Validating:** `secondary_container`
- **Planned/Building:** `tertiary_container`
- **Launched:** Soft Emerald (Custom)
- **Paused/Archived:** `surface_variant`

---

## 3. Typography
We utilize a pairing of **Manrope** (for impact and authority) and **Inter** (for precision and utility).

- **Display & Headlines (Manrope):** These are the "editorial" anchors. Use `display-lg` and `headline-md` with tight letter-spacing (-0.02em) to create a bold, authoritative look.
- **Titles & Body (Inter):** Inter handles the functional load. Use `title-md` for card headers and `body-md` for all primary user input.
- **Labels (Inter):** `label-sm` should be used for metadata and AI persona roles, often in all-caps with +0.05em tracking to ensure legibility at small scales.

---

## 4. Elevation & Depth
Elevation is not about "darkness," but about "light."

- **The Layering Principle:** Depth is achieved by stacking. A `surface-container-lowest` card sitting on a `surface-container-low` background creates a natural lift.
- **Ambient Shadows:** For floating elements, use "Shadow-as-Light." 
  - *Value:* `0px 12px 32px rgba(45, 51, 55, 0.06)`
  - The shadow must be low-opacity and tinted with the `on_surface` color to feel like natural ambient light.
- **The "Ghost Border" Fallback:** If a border is required for accessibility, use the `outline_variant` token at **15% opacity**. Never use 100% opaque borders.

---

## 5. Components

### AI Persona Branding (The "Roundtable" Timeline)
Each AI persona is a distinct entity within the chat-style timeline. Use the following color-coded role labels:
- **Kai (Visionary):** `primary` (#5148d8)
- **Nova (Strategist):** `secondary` (#006b62)
- **Rex (Builder):** `tertiary` (#742fe5)
- **Sage (Critic):** `error` (#ac3149)
- **Luna (User Advocate):** `primary_container` (#bdbaff)
- **Nia (Execution Controller):** `outline` (#757c7f)

**Chat UI Signature:** AI responses should not be in boxes. Use a vertical "accent line" (2px) in the persona’s specific color to the left of the text, utilizing the `surface` background to keep the timeline airy.

### Cards & Tables
- **Cards:** Use `roundedness.xl` (0.75rem). No borders. Use `surface-container-lowest` on top of `surface`.
- **Tables:** Forbid horizontal and vertical divider lines. Instead, use alternating row fills of `surface` and `surface-container-low`. Headers use `label-md` in `on_surface_variant`.
- **Buttons:**
    - **Primary:** Gradient fill (`primary` to `primary_dim`), `roundedness.md`, white text.
    - **Secondary:** Ghost style. No fill, `ghost border` (15% opacity `outline_variant`), `primary` text.
- **Input Fields:** Use `surface-container-highest` for the track. On focus, transition the background to `surface-container-lowest` and apply a 1px `ghost border` in `primary`.

---

## 6. Do's and Don'ts

### Do
- **Do** use whitespace as a separator. If you feel the need for a line, try adding 16px of padding instead.
- **Do** use Manrope for numbers in tables to give them a modern, "data-viz" feel.
- **Do** align text-heavy AI insights with a ragged-right edge to keep the "conversation" feeling human and organic.

### Don't
- **Don't** use pure black (#000000) for text. Use `on_surface` (#2d3337) to maintain the soft editorial tone.
- **Don't** use standard Material Design drop shadows. They are too heavy for this system; stick to the Ambient Shadow spec.
- **Don't** cram components. If a card feels tight, increase the `roundedness` and the internal padding by one step on the scale.